# BlogApp

This is a simple ReactJS application demonstrating React class components, component lifecycle methods like `componentDidMount()` and `componentDidCatch()`, and fetching data from an API.

## Features

- Uses `componentDidMount()` to fetch blog posts using Fetch API.
- Handles errors using `componentDidCatch()` lifecycle method.
- Displays blog posts dynamically using reusable `Post` component.

## Project Structure

```
blogapp/
├── src/
│   ├── App.js
│   ├── Post.js
│   └── Posts.js
```

## Prerequisites

- Node.js and npm installed
- Visual Studio Code or any code editor

## How to Run

1. Clone this repository or extract the ZIP:
   ```bash
   git clone <your-repo-url>
   ```

2. Navigate to the project directory:
   ```bash
   cd blogapp
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Start the development server:
   ```bash
   npm start
   ```

5. Open browser and visit:
   ```
   http://localhost:3000
   ```

## API Used

- JSONPlaceholder: https://jsonplaceholder.typicode.com/posts

## Author

- [Your Name]