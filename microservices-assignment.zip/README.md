# Microservices Assignment: Account & Loan Services

This repository contains two simple Spring Boot microservices developed as part of a hands-on assignment for microservices.

## 🔧 Technologies Used
- Java 17
- Spring Boot
- Maven
- RESTful API

## 🧾 Description

### 1️⃣ Account Microservice
- Endpoint: `GET /accounts/{number}`
- Port: `8080`
- Sample Response:
```json
{
  "number": "00987987973432",
  "type": "savings",
  "balance": 234343
}
```

### 2️⃣ Loan Microservice
- Endpoint: `GET /loans/{number}`
- Port: `8081`
- Sample Response:
```json
{
  "number": "H00987987972342",
  "type": "car",
  "loan": 400000,
  "emi": 3258,
  "tenure": 18
}
```

## 🚀 How to Run

### Step 1: Build Both Projects
```bash
cd account
mvn clean install

cd ../loan
mvn clean install
```

### Step 2: Run Account Service
```bash
cd account
mvn spring-boot:run
```

### Step 3: Run Loan Service
```bash
cd loan
mvn spring-boot:run
```

## 🔍 Testing Endpoints

- [http://localhost:8080/accounts/00987987973432](http://localhost:8080/accounts/00987987973432)
- [http://localhost:8081/loans/H00987987972342](http://localhost:8081/loans/H00987987972342)
