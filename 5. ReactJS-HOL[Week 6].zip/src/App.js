import React from 'react';
import CohortDetails from './CohortDetails';

function App() {
  return (
    <div>
      <CohortDetails 
        name="React Bootcamp" 
        status="ongoing" 
        startDate="2025-08-01" 
        endDate="2025-09-15" 
      />
      <CohortDetails 
        name="Java Spring Training" 
        status="completed" 
        startDate="2025-06-01" 
        endDate="2025-07-10" 
      />
    </div>
  );
}

export default App;
